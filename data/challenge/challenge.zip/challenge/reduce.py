import os
import pandas as pd

# Define paths
src_folder = '.' # Folder containing input CSV files
dst_folder = 'reduced' # Folder to save precision-reduced files

# Make sure the destination folder exists
os.makedirs(dst_folder, exist_ok=True)

# Loop through every CSV file in the data folder
for filename in os.listdir(src_folder):
    if filename.endswith('.csv'):
        src_path = os.path.join(src_folder, filename)
        dst_path = os.path.join(dst_folder, filename)

        # Load the CSV file
        df = pd.read_csv(src_path)

        # Round numeric columns to 4 decimal places
        df = df.apply(lambda col: col.round(3) if col.dtype.kind in 'fc' else col)

        # Save processed DataFrame
        df.to_csv(dst_path, index=False)

print('All CSV files processed. Rounded to 4 decimal places and saved in "reduced" folder.')